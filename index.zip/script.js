const playPauseBtn = document.getElementById('play-pause-btn');
const prevBtn = document.getElementById('prev-btn');
const nextBtn = document.getElementById('next-btn');
const progressBar = document.querySelector('.progress-bar');
const progressBarContainer = document.querySelector('.progress-bar-container');
const currentTimeEl = document.getElementById('current-time');
const totalTimeEl = document.getElementById('total-time');
const playerTitle = document.getElementById('player-title');
const playerArtist = document.getElementById('player-artist');
const playerAlbumArt = document.getElementById('player-album-art');
const songGrid = document.querySelector('.song-grid');

const songs = [
    { title: 'Stuck in Exile', artist: 'Sanjeev Sachdeva', src: 'stuck-in-exile-403529.mp3', cover: 'https://img.freepik.com/free-photo/wet-sphere-reflective-water-abstract-beauty-generated-by-ai_188544-19616.jpg?semt=ais_incoming&w=740&q=80' },
    { title: 'Tell Me What', artist: 'Unknown Artist', src: 'tell-me-what-379638.mp3', cover: 'https://variety.com/wp-content/uploads/2022/07/Music-Streaming-Wars.jpg' },
    { title: 'Alone', artist: 'Unknown Artist', src: 'alone-296348.mp3', cover: 'https://static0.makeuseofimages.com/wordpress/wp-content/uploads/2024/03/woman-listening-to-music-with-headphones.jpg' },
    { title: 'Sima', artist: 'Sima', src: 'simasx27s-songs-240465.mp3', cover: 'https://static.vecteezy.com/system/resources/previews/037/044/052/non_2x/ai-generated-studio-shot-of-black-headphones-over-music-note-explosion-background-with-empty-space-for-text-photo.jpg' },
    { title: 'Quiet Bloom', artist: 'Sanjeev Sachdeva', src: 'quiet-bloom_short-2-403542.mp3', cover: 'https://media.gettyimages.com/id/1385087437/vector/musical-wave.jpg?s=612x612&w=gi&k=20&c=X6gmZ32Ru1zMqB2Dx9HyQEqIs8hhxTAOhmygNI6_K3A=' },
    { title: 'Innovate', artist: 'Sanjeev Sachdeva', src: 'innovate_short-1-403518.mp3', cover: 'https://thumbs.dreamstime.com/b/colorful-word-music-18868783.jpg' },
    { title: 'Blinder', artist: 'Sanjeev Sachdeva', src: 'blinder-403523.mp3', cover: 'https://i0.wp.com/post.medicalnewstoday.com/wp-content/uploads/sites/3/2020/10/Woman-Silhouette-Headphones-Sun-1296x728-Header-1024x575.jpg?w=1155&h=1528' },
    { title: 'Starlight', artist: 'Sanjeev Sachdeva', src: 'stuck-in-exile-403529.mp3', cover: 'https://www.thelabmagofficial.com/wp-content/uploads/2017/11/maxresdefault-825x465-1.jpg' },
    { title: 'Tera Pyar Mera Junoon', artist: 'Unknown Artist', src: 'tera-pyar-mera-junoon-334753.mp3', cover: 'https://getwallpapers.com/wallpaper/full/e/7/b/434320.jpg' },
    { title: 'Tera Roothna', artist: 'Ashir', src: 'romantic-song-tera-roothna-by-ashir-hindi-top-trending-viral-song-231771.mp3', cover: 'https://pendujatt.com.se/uploads/album/tera-roothna-ashir.webp' },
    { title: 'Bollywood Song', artist: 'Unknown Artist', src: 'bollywood-song-313044.mp3', cover: 'https://cdn.shopify.com/s/files/1/0482/5422/2486/files/valentine_day_gifts.jpg?v=1674769325' },
    { title: 'Hindi Song', artist: 'Unknown Artist', src: 'hindi-song-385015.mp3', cover: 'https://img.mensxp.com/media/content/2017/Mar/bollywood-songs-quiz980-1490183479.jpg' },
    { title: 'Saiyaara Title Track', artist: 'Mohit Chauhan', src: 'Title Track Saiyaara 320 Kbps.mp3', cover: 'https://i.scdn.co/image/ab67616d0000b273a7e251b543c77a6ed356dfbe' },
    { title: 'Saiyaara Barbaad', artist: 'Mohit Chauhan', src: 'Barbaad Saiyaara 320 Kbps.mp3', cover: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTVRiwJjoHqjyrnXFWner5kGcWbXvmK4lhayg&s' },
];

let audio = new Audio();
let isPlaying = false;
let currentSongIndex = 0;

function renderSongs() {
    songGrid.innerHTML = '';
    songs.forEach((song, index) => {
        const songCard = document.createElement('div');
        songCard.classList.add('song-card');
        songCard.innerHTML = `
            <img src="${song.cover}" alt="${song.title} Album Art">
            <h3>${song.title}</h3>
            <p>${song.artist}</p>
        `;
        songCard.addEventListener('click', () => {
            playSong(index);
        });
        songGrid.appendChild(songCard);
    });
}

function playSong(index) {
    if (index !== currentSongIndex) {
        currentSongIndex = index;
        audio.src = encodeURI(songs[currentSongIndex].src);
        updatePlayerInfo();
        
        audio.play();
    } else if (!isPlaying) {
        audio.play();
    }
    
    isPlaying = true;
    playPauseBtn.classList.remove('fa-play-circle');
    playPauseBtn.classList.add('fa-pause-circle');
}

function pauseSong() {
    audio.pause();
    isPlaying = false;
    playPauseBtn.classList.remove('fa-pause-circle');
    playPauseBtn.classList.add('fa-play-circle');
}

function updatePlayerInfo() {
    const song = songs[currentSongIndex];
    playerTitle.textContent = song.title;
    playerArtist.textContent = song.artist;
    playerAlbumArt.src = song.cover;
}

playPauseBtn.addEventListener('click', () => {
    if (isPlaying) {
        pauseSong();
    } else {
        playSong(currentSongIndex);
    }
});

prevBtn.addEventListener('click', () => {
    currentSongIndex = (currentSongIndex - 1 + songs.length) % songs.length;
    playSong(currentSongIndex);
});

nextBtn.addEventListener('click', () => {
    currentSongIndex = (currentSongIndex + 1) % songs.length;
    playSong(currentSongIndex);
});

audio.addEventListener('timeupdate', () => {
    const { duration, currentTime } = audio;
    if (duration) {
        const progressPercent = (currentTime / duration) * 100;
        progressBar.style.width = `${progressPercent}%`;

        const currentMins = Math.floor(currentTime / 60);
        const currentSecs = Math.floor(currentTime % 60);
        const totalMins = Math.floor(duration / 60);
        const totalSecs = Math.floor(duration % 60);

        currentTimeEl.textContent = `${currentMins}:${currentSecs < 10 ? '0' : ''}${currentSecs}`;
        totalTimeEl.textContent = `${totalMins}:${totalSecs < 10 ? '0' : ''}${totalSecs}`;
    }
});

progressBarContainer.addEventListener('click', (e) => {
    const width = progressBarContainer.clientWidth;
    const clickX = e.offsetX;
    const duration = audio.duration;
    audio.currentTime = (clickX / width) * duration;
});

audio.addEventListener('ended', () => {
    nextBtn.click();
});

renderSongs();
updatePlayerInfo();